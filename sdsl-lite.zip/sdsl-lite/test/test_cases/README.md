# Test inputs

This directory contains some small inputs and will
be populated by larger inputs when running the
all tests.

TODO: describe what the ending of the files mean.
