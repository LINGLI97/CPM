typedef unsigned int uint128_t __attribute__((mode(TI)));

int main() {
    return 0;
}
